package fr.sauvageboris.training.exercice1;


// Installer les outils
// Créer un premier projet java qui affiche votre Nom et Prénom
// Exécuter le projet
public class Exercice1 {

    public static void main(String[] args) {
        String firstname = "Boris";
        String lastname = "SAUVAGE";
        System.out.println("Je m'appelle " + firstname + lastname);
    }

}