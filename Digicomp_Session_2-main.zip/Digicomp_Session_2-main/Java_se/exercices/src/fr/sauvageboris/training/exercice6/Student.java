package fr.sauvageboris.training.exercice6;

public class Student {

    String firstName;
    double mark;

    public Student(String firstName, double mark) {
        this.firstName = firstName;
        this.mark = mark;
    }

}